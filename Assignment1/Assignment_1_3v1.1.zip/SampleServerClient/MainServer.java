import java.util.*;
import java.lang.*;
import java.net.ServerSocket;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class MainServer
{
	
	public static void main(String[] args) {
		Server server = new Server();
		server.startServer();

		Shared s = new Shared().getInstance();
		s.start();
	}
}