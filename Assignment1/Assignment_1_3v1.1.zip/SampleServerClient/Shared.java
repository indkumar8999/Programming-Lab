import java.util.*;
import java.lang.*;
import java.net.ServerSocket;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;


class Shared extends Thread
{
	public static Shared s;
	public static int cookies = 10, snacks = 10;
    public static ArrayList<ClientInfo> q;
    // public Semaphore sema;
	Shared()
	{
        // this.sema = MainServer.sema;
		q = new ArrayList<ClientInfo>();
	}
	public static Shared getInstance(){
		if(s == null){
			s = new Shared();
			return s;
		}else{
			return s;
		}
    }
    
    public void run()
    {

    }
}
