import java.util.*;
import java.lang.*;
import java.net.ServerSocket;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

class ClientInfo
{
	public int rollno, roomno, tea, coffee, cookies, snacks;
    public int estimated_time;
	public ClientInfo(int rollno, int roomno, int tea, int coffee, int cookies, int snacks){
		this.rollno = rollno;
		this.roomno = roomno;
		this.tea = tea;
		this.coffee = coffee;
		this.cookies = cookies;
        this.snacks = snacks;
        estimated_time = 0;
    }
    
}